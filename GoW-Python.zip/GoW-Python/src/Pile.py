from src.Card import Card

class Pile:
	
	pile = [Card()]
	
	def getSize(self):
		return "s"
	
	def clear(self):
		
	def addCard(self):
		
	
