from src.cardDeck import cardDeck
from src.Card import Card
from src.Pile import Pile


p = cardDeck()
s = Card()
a = Pile()

#s.setCard(10,1)
#print(str(s.getCardRank()) + " " + str(s.getCardSuit()))

"""print("Before Shuffle")
p.fill()
p.displayDeck()

print("\n\n\nAfter Shuffle\n")
p.shuffleDeck()
p.displayDeck()"""

print(a.test())